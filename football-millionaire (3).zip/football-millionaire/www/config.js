window.CFG = {
  APP_NAME: "مليونير كرة القدم",

  // الأسئلة الأونلاين (بتتحدّث من GitHub بدون ما تعدّل التطبيق).
  // ⚠ ما تغيّرش USERNAME/REPO — خطوة البناء على GitHub بتحط اسم حسابك ومستودعك لوحدها.
  QUESTIONS_URL: "https://raw.githubusercontent.com/USERNAME/REPO/main/questions.json",

  // قاعدة بيانات واحد ضد واحد (Firebase Realtime Database) — بتتحط لوحدها من ملف firebase-db-url.txt في المستودع.
  FIREBASE_DB: "",

  // تسجيل الدخول بإيميل حقيقي على السحابة (اختياري):
  // FIREBASE: { apiKey:"...", authDomain:"xxx.firebaseapp.com", projectId:"xxx", appId:"..." }
  FIREBASE: null
};
