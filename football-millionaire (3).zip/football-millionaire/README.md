# مليونير كرة القدم ⚽👑

## بناء التطبيق
ارفع `football-millionaire.zip` على GitHub (بنفس الاسم) وهيتبني الـ APK تلقائياً (Actions ← Artifacts).

## الأسئلة الأونلاين (تتحدث بدون تنزيل تطبيق جديد)
ارفع ملف `questions.json` في أول المستودع (نفس مكان الـ zip). اللعبة بتحمّله لما يكون فيه نت،
وبتختار أسئلة جديدة للاعب مايشوفهاش قبل كده. أوفلاين: بتكرر حزمة محفوظة (حتى 200 سؤال).
صيغة السؤال: `[السؤال, الصحيحة, خطأ1, خطأ2, خطأ3, المستوى 1-3]`.

## تفعيل واحد ضد واحد (مرة واحدة)
1. افتح console.firebase.google.com ← Create project (أي اسم، وقفل Analytics).
2. Build ← Realtime Database ← Create Database ← Start in test mode ← Enable.
3. من تبويب Rules الصق: `{"rules":{".read":true,".write":true}}` ← Publish.
4. انسخ رابط القاعدة اللي فوق (`https://xxxx-default-rtdb.firebaseio.com`).
5. في GitHub: Add file ← Create new file ← الاسم `firebase-db-url.txt` ← الصق الرابط ← Commit.
